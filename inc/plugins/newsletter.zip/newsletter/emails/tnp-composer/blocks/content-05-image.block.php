
<table border="0" cellpadding="0" align="center" cellspacing="0" width="100%">
    <tr>
        <td bgcolor="#ffffff" align="center" style="padding: 0;">
            
            <div class="tnpc-row-edit" data-type="image">
                <a href="#" target="_blank">
                    <img src="https://unsplash.it/800/300?image=998" border="0" alt="Insert alt text here" width="<?php echo $width ?>" style="width: <?php echo $width ?>px; max-width: 100%!important; height: auto!important;display: block; color: #666666;" class="img-max">
                </a>
            </div>
            
        </td>
    </tr>
</table>
