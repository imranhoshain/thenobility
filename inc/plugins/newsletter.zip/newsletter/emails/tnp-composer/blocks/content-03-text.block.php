
<table border="0" cellpadding="0" align="center" cellspacing="0" width="100%">
    <tr>
        <td bgcolor="#ffffff" align="center" style="padding: 20px 15px 20px 15px;">
            
            <table border="0" cellpadding="0" cellspacing="0" class="responsive-table" width="100%" style="width: 100%!important">
                <tr>
                    <td align="left" style="text-align: left; padding: 0 0 0 0; font-size: 16px; line-height: 25px; color: #666666; font-family: Helvetica, Arial, sans-serif;" class="padding-copy tnpc-row-edit" data-type="text">
                        The judge, by the way, was the King; and as he wore his crown over the wig, (look at the frontispiece if 
                        you want to see how he did it,) he did not look at all comfortable, and it was certainly not becoming.
                    </td>
                </tr>
            </table>
            
        </td>
    </tr>
</table>
